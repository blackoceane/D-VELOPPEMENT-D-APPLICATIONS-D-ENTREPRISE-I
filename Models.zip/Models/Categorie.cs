﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L_Joyce.Models
{
    public class Categorie
    {
        public int Id_Categorie { get; set; }

        public string Nom { get; set; }
    }
}
