﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L_Joyce.Models
{
    public  class Vendeur
    {
        public int Id_vendeur { get; set; }
        public string Nom { get; set; }
    }
}
