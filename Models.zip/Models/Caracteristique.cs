﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L_Joyce.Models
{
    public class Caracteristique
    {
        public int Id_Caracteristique { get; set; }

        public string Description { get; set; }
    }
}
